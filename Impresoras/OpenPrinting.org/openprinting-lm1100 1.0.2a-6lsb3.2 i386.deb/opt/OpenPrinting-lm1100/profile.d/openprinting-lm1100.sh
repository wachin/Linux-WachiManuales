export PATH=/opt/OpenPrinting-lm1100/bin:$PATH
