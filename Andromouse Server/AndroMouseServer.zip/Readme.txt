AndroMouse Server 6.3
__________________________________________________

Thank you for downloading AndroMouse!!

AndroMouse lets you convert your Android smartphone into wireless mouse, keyboard and much more.
AndroMouse connects to your computer(Windows/Mac/Linux) using your existing Wifi or Bluetooth connection.

Please visit http://andromouse.com for a quick tutorial on how to connect AndroMouse to your computer and to learn
about all the exciting features. Post your question and issues on the website.
Based on your comments and recommendations, I will be updating AndroMouse frequently. You can also search YouTube for
AndroMouse tutorial videos.

Once again thank you for considering AndroMouse. Have fun with AndroMouse!

Note: To use AndroMouse desktop server, you need to have Java installed in your computer. You can check if you have Java installed on your computer by following instructions here: http://andromouse.com/?page_id=336

Java download link: http://java.com/en/download/index.jsp