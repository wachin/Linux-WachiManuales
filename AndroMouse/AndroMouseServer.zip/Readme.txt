AndroMouse Server 5.0
__________________________________________________

Thank you for your interest in AndroMouse.

AndroMouse lets you convert your Android device into wireless mouse, keyboard and more. AndroMouse uses Google voice recognition for accurate and fast voice recognition that you can transfer to your computer.
AndroMouse connects to your computer using your existing wireless connection(Windows/Mac/Linux). If your computer is equipped with Bluetooth or if you have a bluetooth dongle, you don't need wifi(Windows).
It also features advanced keyboard including function and special keys.

Please visit http://andromouse.com for a quick tutorial. Post your question and issues on the website or send an email to surajbh@gmail.com
Based on your comments and recommendations, we will be updating AndroMouse frequently.


Again thank you for your consideration. Have fun with AndroMouse.

Please make sure that the app version matches the server version for compability.

Note: To use AndroMouse desktop server, you need to have Java installed in your computer. Please download it from: http://java.com/en/download/index.jsp
