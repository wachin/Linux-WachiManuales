// created on 5/16/2006 at 10:47 AM
using System;
using Gnome;

namespace 
{
	public class New Gnome# Program : Program
	{
		public CreatedProgram (string[] args) : base ("ChangeMe", "0.1", Gnome.Modules.Info, args)
		{
		}
	}
}
