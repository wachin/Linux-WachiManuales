# Platforms tested: (Source-Code)

*  Windows 7 (32bit)
*  Mac OS: Lion (32bit), Mountain Lion (64bit), Mavericks (64bit)
*  Linux Mint 17: Ubuntu

Not Running: (Linux Mint Debian: does not work without tweaking the
ui-code of the main ui-file. It is a problem of the installed
QT-Version)
