# Customizing Panconvert

## General Settings

* In the General Settings you can configure with which Converter Panconvert will start up.
* Also you can configure if you will use the manual or the Standard Converter.
* Here some Path-configuration can be done

## Size Settings
Here you can force Panconvert to remember the size and position of Windows and Dialogs.

* Main Window Size and Position
* Log Window Size and Position
* Dialog Positions