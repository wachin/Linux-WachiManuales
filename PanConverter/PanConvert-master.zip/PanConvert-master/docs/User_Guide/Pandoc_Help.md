# Pandoc Help

Detailed help you will find at [pandoc Hilfe](http://pandoc.org/MANUAL.html)


## Supported Formats:

All through pandoc supported formats can be used in PanConvert

To use all not explicitly listed formats of pandoc, you have to use the
manual converter.
