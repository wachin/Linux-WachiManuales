Dolphin Folder Color
====================

A KDE Service Menu for coloring the folders so fast, also has the ability to color a selected set of folders.
**Supports Plasma 5 and KDE4**

## Installation
You just need to run the script. **install.sh** with a click and restart dolphin.

**Note**: should not be started from the shell. And it depends on KDialog and kdesu.

## Screenshots
### Service Menu
 ![Service Menu](screenshot1.png)
### Custom Icon
 ![Custom Icon](screenshot2.png)
